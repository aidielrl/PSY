<?php 
include_once("inc/db_connect.php");
include("export.php");
include("inc/header.php"); 
?>
<title>webdamn.com : Demo Exporting Data to Excel using PHP & MySQL</title>
<?php include('inc/container.php');?>
<div class="container">	
	<h2>Example: Exporting Data to Excel using PHP & MySQL</h2>
	<div class="well-sm col-sm-12">
		<div class="btn-group pull-right">	
			<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">					
				<button type="submit" id="dataExport" name="dataExport" value="Export to excel" class="btn btn-info">Export To Excel</button>
			</form>
		</div>
	</div>				  
	<table id="" class="table table-striped table-bordered">
		<tr>
			<th>Name</th>
			<th>Gender</th>
			<th>Age</th>
			<th>Skills</th>			
			<th>Address</th>
			<th>Designation</th>
		</tr>
		<tbody>
			<?php foreach($developersData as $developer) { ?>
			   <tr>
			   <td><?php echo $developer ['name']; ?></td>
			   <td><?php echo $developer ['gender']; ?></td>
			   <td><?php echo $developer ['age']; ?></td>  
				<td><?php echo $developer ['skills']; ?></td>			   
			   <td><?php echo $developer ['address']; ?></td>
			   <td><?php echo $developer ['designation']; ?></td>   
			   </tr>
			<?php } ?>
		</tbody>
    </table>		
</div>
<?php include('inc/footer.php');?>




