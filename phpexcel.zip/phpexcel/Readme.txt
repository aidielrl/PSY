How to run this script
1. Download and Unzip file on your local system.
2. Put this file inside root directory
3. Database Configuration

Database Configuration
Open phpmyadmin
Create Database empdata
Import database empdata.sql (available inside zip package)
Open Your browser put inside browser “http://localhost/phpexcl”